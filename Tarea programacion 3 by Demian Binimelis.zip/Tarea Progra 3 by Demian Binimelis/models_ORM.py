from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from database import Base

class Personaje(Base):
    __tablename__ = "personajes"
    id = Column(Integer, primary_key=True)
    nombre_personaje = Column(String, nullable=False)
    experiencia_personaje = Column(Integer, default=0)
    misiones_personaje = relationship("Mision", back_populates="personaje", order_by="Mision.orden")

class Mision(Base):
    __tablename__= "misiones"
    id = Column(Integer, primary_key=True)
    descripcion_Mision = Column(String, nullable=False)
    Experiencia_Mision = Column(Integer, default=5)
    personaje_id = Column(Integer, ForeignKey("personajes.id")) 
    orden = Column(Integer)
    personaje = relationship("Personaje", back_populates="misiones_personaje")