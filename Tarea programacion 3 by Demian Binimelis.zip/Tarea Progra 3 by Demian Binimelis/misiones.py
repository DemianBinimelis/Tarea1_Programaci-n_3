class ColaMisiones:
    def __init__(self, capacidad_maxima=100):
        self.capacidad = capacidad_maxima
        self.items = [None] * capacidad_maxima
        self.cabeza = 0 
        self.cola = 0    
        self.tamano = 0 

    def enqueue(self, mission):
        if self.tamano ==self.capacidad:
            self._redimensionar()        
        self.items[self.cola] =mission
        self.cola = (self.cola+1) %self.capacidad
        self.tamano+= 1

    def dequeue(self):
        if self.is_empty():
            return None
        
        mission = self.items[self.cabeza]
        self.items[self.cabeza] =None 
        self.cabeza = (self.cabeza + 1) % self.capacidad
        self.tamano -= 1
        return mission

    def first(self):
        return None if self.is_empty() else self.items[self.cabeza]
    def is_empty(self):
        return self.tamano == 0
    def size(self):
        return self.tamano

    def _redimensionar(self):
        nueva_capacidad= self.capacidad *2
        nuevos_items = [None] * nueva_capacidad
        
        for i in range(self.tamano):
            nuevos_items[i] = self.items[(self.cabeza + i) % self.capacidad]
        
        self.items = nuevos_items
        self.cabeza = 0
        self.cola = self.tamano
        self.capacidad = nueva_capacidad