from fastapi import FastAPI, HTTPException 
from pydantic import BaseModel
from database import Base, engine, session
from models_ORM import Personaje, Mision  
from misiones import ColaMisiones


Base.metadata.create_all(engine)

app = FastAPI()
Misiones = ColaMisiones()

class crear_Personaje(BaseModel):
    Nombre: str

class crear_Mision(BaseModel):
    Detalles_Mision: str
    Experiencia: int = 5

@app.post("/personaje")
def crear_Nuevo_Personaje(datos: crear_Personaje):
    nuevo_Personaje = Personaje(nombre_personaje=datos.Nombre) 
    session.add(nuevo_Personaje)
    session.commit()
    return {"Mensaje": "Se ha creado un nuevo personaje", "id": nuevo_Personaje.id}


@app.post("/misiones")
def crearNuevaMision(mision: crear_Mision):
    mision_Nueva = Mision(descripcion_Mision=mision.Detalles_Mision, Experiencia_Mision=mision.Experiencia)
    session.add(mision_Nueva)
    session.commit()
    return {"Mensaje": "Se ha creado una nueva mision", "id": mision_Nueva.id}


@app.post("/personajes/{id_Personaje}/misiones/{id_Mision}")
def dar_Mision(id_Personaje: int, id_Mision: int):
    personaje = session.get(Personaje, id_Personaje)
    mision_obj = session.get(Mision, id_Mision)

    if not personaje or not mision_obj:
        raise HTTPException(status_code=404, detail="La mision o el personaje no se han encontrado o no existen")
    if mision_obj.personaje_id is not None:
        raise HTTPException(status_code=400, detail="La mision ya ha sido asignada")

    Misiones.enqueue(mision_obj)
    
    mision_obj.personaje = personaje
    mision_obj.orden = Misiones.size()
    session.commit()
    return {"Mensaje": "Se ha asignado una mision"}


@app.get("/personajes/{personaje_id}/misiones")
def ver_misiones_asignadas(personaje_id: int):
    personaje = session.get(Personaje, personaje_id)
    if not personaje:
        raise HTTPException(status_code=404, detail="No se ha encontrado el personaje")
    
    return [
        {
            "id": m.id,
            "descripcion": m.descripcion_Mision,
            "xp": m.Experiencia_Mision,
            "orden": m.orden
        } 
        for m in personaje.misiones_personaje 
    ]


@app.post("/personajes/{personaje_id}/completar")
def completar_mision(personaje_id: int):
    personaje = session.get(Personaje, personaje_id)
    if not personaje:
        raise HTTPException(status_code=404, detail="No se ha encontrado el personaje")
    
    mision_obj = Misiones.dequeue()
    if not mision_obj:
        raise HTTPException(status_code=404, detail="No hay misiones para completar")
    
    if mision_obj.personaje_id != personaje_id:
        raise HTTPException(status_code=400, detail="La misión no pertenece a este personaje")

    ganancia_xp = mision_obj.Experiencia_Mision
    session.delete(mision_obj)
    
    personaje.experiencia_personaje += ganancia_xp
    session.commit()
    
    return {
        "mensaje": "Misión completada",
        "xp_ganado": ganancia_xp,
        "xp_total": personaje.experiencia_personaje
    }